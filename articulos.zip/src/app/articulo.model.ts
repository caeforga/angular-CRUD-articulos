export class Articulo {
    constructor( public descripcion: string, public precio:number) {}
}